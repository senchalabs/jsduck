/**
 * The GeekFlicks application class.
 */
Ext.application({

    name: "GeekFlicks",
    appFolder: "app",

    autoCreateViewport: true,

    controllers: [
        'Movies'
    ]
});
